package com.test.bean;

public interface Test {
	 void display();
}
